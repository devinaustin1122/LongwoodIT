var express = require('express');
const { response } = require('../app');
var mysql = require('mysql');
var router = express.Router();

var connection = mysql.createConnection({
    host: 'localhost',
    port: '3306',
    database: 'todo_db',
    user: 'root',
    password: ''
});

connection.connect(function (err) {
    if (err) {
        console.error('error connecting: ' + err.stack);
        return;
    }
    console.log('connected as id ' + connection.threadId);
});

// router.get('/tasks', function (req, res, next) {
//     connection.query('SELECT * FROM task_list', function (error, data, fields) {
//         if (error) throw error;
//         res.json(data);
//     }); 
// });

router.get('/tasks/:date/:user', function (req, res, next) {
    connection.query('SELECT tasks FROM task_list WHERE user = \'' + req.params.user + '\' AND date = \'' + req.params.date + '\'', function (error, data, fields) {
        console.log('SELECT tasks FROM task_list WHERE user = \'' + req.params.user + '\' AND date = \'' + req.params.date + '\'');
        if (error) throw error;
        res.json(data);
    });
});

router.get('/report', function (req, res, next) {
    connection.query('SELECT a.user, a.DATE, tasks FROM task_list AS a WHERE DATE = \( SELECT MAX(DATE) FROM task_list AS b WHERE a.user = b.user\)', function (error, data, fields) {
        console.log('SELECT a.user, a.DATE, tasks FROM task_list AS a WHERE DATE = \( SELECT MAX(DATE) FROM task_list AS b WHERE a.user = b.user\)');
        if (error) throw error;
        res.json(data);
    });
});

router.get('/dates/:user', function (req, res, next) {
    connection.query('SELECT DISTINCT date FROM task_list WHERE user = \'' + req.params.user + '\'', function (error, data, fields) {
        if (error) throw error;
        res.json(data);
    });
});

router.post('/', function (req, res, next) {
    const {taskList} = req.body;
    const {user, date, tasks} = taskList;

    connection.query('DELETE FROM task_list WHERE date = \'' + date + '\' AND user = \'' + user + '\';');
    connection.query('INSERT INTO task_list (date, tasks, user) VALUES(\'' + date + '\', \'' + JSON.stringify(tasks) + '\',\'' + user + '\');')
    res.end();

})

router.post('/delete', function (req, res, next) {
    const result = connection.query('DELETE FROM task_list WHERE date = \'' + req.body.date + '\' AND user = \'' + req.body.user + '\';');
    res.end();
});

module.exports = router; 